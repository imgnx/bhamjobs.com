# openai Directory

## Description
Contains the openai area of the repo under `srv/bhamjobs.com/old-bhamjobs/app/api/openai` inside Dinglehopper. Use cases focus on maintaining or extending the responsibilities assigned to this directory.

## Manifesto
- Treat `srv/bhamjobs.com/old-bhamjobs/app/api/openai` as the authoritative home for the openai area of the repo and keep changes scoped to that intent.
- Document how the contents interact with the rest of Dinglehopper so future contributors can understand the workflows.
- Keep clarity, accessibility, and reliability high so this area continues to support its use cases over time.
